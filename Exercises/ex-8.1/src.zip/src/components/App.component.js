import React from "react";

class App extends React.Component {
  state = { favoriteColor: "green" };

  componentDidMount() {
    setTimeout(() => {
      this.setState({ favoriteColor: "yellow" });
    }, 1000);
  }
  componentDidUpdate() {
    const div = document.querySelector("#new");
    div.textContent = `The updated favorite color is ${this.state.favoriteColor}`;
  }
  render() {
    return (
      <div>
        <h1>My favorite color is : {this.state.favoriteColor}</h1>
        <div id="new"></div>
      </div>
    );
  }
}

export default App;
