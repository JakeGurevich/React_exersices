import "./square.css";
const Square = (props) => {
  return <div className={props.color}></div>;
};
export default Square;
