import React from "react";
import Square from "./Square.component";
class App extends React.Component {
  state = { color: "red" };

  async componentDidMount() {
    await setTimeout(() => {
      this.setState({ color: "green" });
    }, 500);
    setTimeout(() => {
      this.setState({ color: "blue" });
    }, 1000);
    setTimeout(() => {
      this.setState({ color: "yellow" });
    }, 1500);
    setTimeout(() => {
      this.setState({ color: "brown" });
    }, 2000);
    setTimeout(() => {
      this.setState({ color: "round" });
    }, 2500);
  }
  componentDidUpdate() {}
  render() {
    return (
      <div>
        <Square color={this.state.color} />
      </div>
    );
  }
}

export default App;
