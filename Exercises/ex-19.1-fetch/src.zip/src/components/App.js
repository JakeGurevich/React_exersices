import React from "react";
import Fetch from "./Fetch";
import "./app.css";

const App = () => {
  return (
    <div>
      <Fetch />
    </div>
  );
};
export default App;
