import React, { useEffect, useState } from "react";
import axios from "axios";

const Fetch = () => {
  const [term, setTerm] = useState("");
  const [result, setResult] = useState([]);
  console.log(result);
  useEffect(() => {
    const search = async () => {
      const { data } = await axios.get("https://swapi.dev/api/films/1");
      setResult(data);
    };
    search();
  }, [term]);

  return (
    <React.Fragment>
      <h2>Film: {result.title}</h2>
      <h3>Director: {result.director}</h3>
    </React.Fragment>
  );
};
export default Fetch;
