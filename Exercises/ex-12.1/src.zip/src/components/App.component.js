import React from "react";
import axios from "axios";
import Button from "./Button";
import Joke from "./Joke";
import "./app.css";

class App extends React.Component {
  state = { joke: "", category: [], specJoke: "" };
  fetchJoke = async () => {
    const res = await axios.get("https://api.chucknorris.io/jokes/random");
    console.log(res.data.value);
    this.setState({ joke: res.data.value });
  };
  displayCategories = async () => {
    const res = await axios.get("https://api.chucknorris.io/jokes/categories");
    console.log(res.data);
    this.setState({ category: res.data });
  };
  fetchSpecJoke = async (c) => {
    const res = await axios.get(
      `https://api.chucknorris.io/jokes/random?category=${c}`
    );
    console.log(res.data.value);

    this.setState({ specJoke: res.data.value });
  };

  render() {
    return (
      <div>
        <Button name="Get Joke" onClick={this.fetchJoke} />
        <Button name="Get Categories" onClick={this.displayCategories} />
        <Joke joke={this.state.joke} />
        <div className="category">
          {this.state.category.map((c, i) => {
            return (
              <Button name={c} key={i} onClick={() => this.fetchSpecJoke(c)} />
            );
          })}
        </div>
        <Joke joke={this.state.specJoke} />
      </div>
    );
  }
}

export default App;
