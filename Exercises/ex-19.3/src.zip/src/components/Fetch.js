import React, { useEffect, useState } from "react";
import axios from "axios";
import Spiner from "./Spiner";

const Fetch = () => {
  const [term, setTerm] = useState("react");
  const [result, setResult] = useState([]);
  const [submit, setSubmit] = useState(false);
  const [spiner, setSpiner] = useState(false);

  useEffect(() => {
    const search = async () => {
      setSpiner(true);
      try {
        const { data } = await axios.get(
          `https://hn.algolia.com/api/v1/search?query=${term}`
        );
        const { hits } = data;
        setSpiner(false);
        console.log(hits);
        setResult(hits);
      } catch (err) {
        console.log(err.message);
      }
    };
    search();
  }, [submit]);

  return (
    <React.Fragment>
      <label>Countries :</label>
      <input
        type="text"
        value={term}
        onChange={(e) => setTerm(e.target.value)}
      ></input>
      <button onClick={() => setSubmit(true)}>Submit</button>
      {spiner && <Spiner />}
      <div className="wrap">
        {result.map((c) => {
          return (
            <a key={c.title} href={c.url}>
              {c.title}
            </a>
          );
        })}
      </div>
    </React.Fragment>
  );
};
export default Fetch;
