import React, { useState } from "react";

const Text = (props) => {
  const [sec, setSec] = useState();
  const [min, setMin] = useState();
  const [hour, setHour] = useState();
  const inputHandlerS = (e) => {
    console.log(e.target.value);
    setSec(e.target.value);
    setMin(e.target.value / 60);
    setHour(e.target.value / 60 / 60);
  };
  const inputHandlerM = (e) => {
    console.log(e.target.value);
    setMin(e.target.value);
    setSec(e.target.value * 60);
    setHour(e.target.value / 60);
  };
  const inputHandlerH = (e) => {
    console.log(e.target.value);
    setHour(e.target.value);
    setSec(e.target.value * 60 * 60);
    setMin(e.target.value * 60);
  };

  return (
    <React.Fragment>
      <label for="sec">Seconds : </label>
      <input
        type="text"
        value={sec}
        id="sec"
        onChange={(e) => {
          inputHandlerS(e);
        }}
      ></input>
      <label for="min">Minuts : </label>
      <input
        type="text"
        id="min"
        value={min}
        onChange={(e) => {
          inputHandlerM(e);
        }}
      ></input>
      <label for="hour">Hours : </label>
      <input
        type="text"
        id="hour"
        value={hour}
        onChange={(e) => {
          inputHandlerH(e);
        }}
      ></input>
    </React.Fragment>
  );
};
export default Text;
