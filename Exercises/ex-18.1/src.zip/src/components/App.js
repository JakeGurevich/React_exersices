import React from "react";
import Text from "./Text";
const str = `Save it to your state.
The user can press an icon to change the todo as
completed.
The user can press an icon to change the todo as not
completed.
If the todo is completed cross the name out and change the
icon to a “check”`;
const num = 10;
const App = () => {
  return (
    <div>
      <Text txt={str} n={num} />
    </div>
  );
};
export default App;
