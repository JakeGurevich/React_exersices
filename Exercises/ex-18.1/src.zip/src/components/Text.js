import React, { useState } from "react";

const Text = (props) => {
  console.log(props.n);
  const [show, setShow] = useState(false);
  let res = props.txt.substring(0, props.n);
  const showText = () => {
    setShow(true);
  };
  const hideText = () => {
    setShow(false);
  };
  const showMore = (
    <a href="#" onClick={showText}>
      ...Read more
    </a>
  );
  const showLess = (
    <a href="#" onClick={hideText}>
      show less
    </a>
  );

  return (
    <React.Fragment>
      {show ? props.txt : res}
      {show ? showLess : showMore}
    </React.Fragment>
  );
};
export default Text;
