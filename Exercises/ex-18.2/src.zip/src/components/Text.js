import React, { useState } from "react";
const tasks = [
  { name: "CSS", completed: true },
  { name: "JavaScript", completed: true },
  { name: "Learn React", completed: false },
  { name: "Learn mongoDB", completed: false },
  { name: "Learn Node JS", completed: false },
];
const y = <span> &#x2713;</span>;
const x = <span> &#x2715;</span>;

const Text = (props) => {
  const changeStatus = (name) => {
    console.log(name);
    const updated = taskList.map((task) => {
      return task.name === name
        ? { ...task, completed: !task.completed }
        : { ...task };
      console.log({ ...task });
    });
    setTask(updated);
  };

  const [taskList, setTask] = useState(tasks);

  return (
    <React.Fragment>
      {taskList.map((task, index) => {
        return (
          <li
            key={task.name}
            id={index}
            className={task.completed ? "strike" : ""}
          >
            {task.name}
            <span className="color" onClick={() => changeStatus(task.name)}>
              {task.completed ? y : x}
            </span>
            ;
          </li>
        );
      })}
    </React.Fragment>
  );
};
export default Text;
