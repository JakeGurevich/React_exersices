import React from "react";
import Square from "./Square.component";
import Spiner from "./Spiner.componnet";
class App extends React.Component {
  state = { color: "red" };

  componentDidMount() {}
  componentDidUpdate() {}
  render() {
    return (
      <div>
        <Spiner />
        <Spiner msg="Loading content" />
      </div>
    );
  }
}

export default App;
