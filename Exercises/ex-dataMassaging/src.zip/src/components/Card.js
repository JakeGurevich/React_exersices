const Card = (props) => {
  return (
    <div className="card">
      <h2>Name : {props.name}</h2>
      <h2>Birthday : {props.bd}</h2>
      <h3>Favorite meats : {props.meats}</h3>
      <h3>Favorite fish foods : {props.fish}</h3>
    </div>
  );
};
export default Card;
