import React from "react";
import axios from "axios";
import Button from "./Button";
import Joke from "./Joke";
import "./app.css";
import { data } from "../data";
import Name from "./Name";
import Card from "./Card";

class App extends React.Component {
  state = { names: [], before1990: [] };
  displayNames = (arr) => {
    const newArr = arr.map((el) => {
      return el.name;
    });
    console.log(newArr);
    this.setState({ names: newArr });
  };
  displayBefore = (arr) => {
    const newArr = arr.filter((el) => {
      let str = el.birthday.slice(el.birthday.length - 4);
      console.log(str);
      return str < 1990 ? el : "";
    });
    this.setState({ before1990: newArr });
    console.log(newArr);
  };
  componentDidMount() {
    // this.displayData();
    this.displayNames(data);
    this.displayBefore(data);
  }
  render() {
    return (
      <div>
        <Name names={this.state.names} />
        {this.state.before1990.map((e, i) => {
          return (
            <Card
              key={i}
              name={e.name}
              bd={e.birthday}
              meats={e.favoriteFoods.meats.join(" , ")}
              fish={e.favoriteFoods.fish.join(" , ")}
            />
          );
        })}
      </div>
    );
  }
}
export default App;
