const Name = (props) => {
  return (
    <ul>
      Names :
      {props.names.map((n, i) => {
        return <li key={i + "n"}>{n}</li>;
      })}
    </ul>
  );
};
export default Name;
