const Joke = (props) => {
  return <div className="joke">{props.joke}</div>;
};
export default Joke;
