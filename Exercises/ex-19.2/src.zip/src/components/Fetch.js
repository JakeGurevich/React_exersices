import React, { useEffect, useState } from "react";
import axios from "axios";

const Fetch = () => {
  const [term, setTerm] = useState("");
  const [result, setResult] = useState([]);

  useEffect(() => {
    const search = async () => {
      const { data } = await axios.get("https://restcountries.eu/rest/v2/all");
      setResult(data);
    };
    search();
  }, [term]);

  return (
    <React.Fragment>
      <label>Countries :</label>
      <input
        type="text"
        value={term}
        onChange={(e) => setTerm(e.target.value)}
      ></input>
      <ul>
        {result.map((c) => {
          const termCap = term.charAt(0).toUpperCase() + term.slice(1);
          if (c.name.startsWith(termCap)) {
            return <li key={c.name}>{c.name}</li>;
          }
        })}
      </ul>
    </React.Fragment>
  );
};
export default Fetch;
