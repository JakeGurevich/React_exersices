import React from "react";
import Square from "./Square.component";
class App extends React.Component {
  state = { show: false };

  componentDidMount() {
    setTimeout(() => {
      this.setState({ show: true });
    }, 2000);
    setTimeout(() => {
      this.setState({ show: false });
    }, 6000);
  }
  componentDidUpdate() {}
  render() {
    return (
      <div>
        <Square size={this.state.show ? "smaller" : null} />
        <Square size={this.state.show ? "normal" : null} />
        <Square size={this.state.show ? "small" : null} />
      </div>
    );
  }
}

export default App;
