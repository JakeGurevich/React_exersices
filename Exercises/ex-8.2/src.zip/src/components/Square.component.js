import "./square.css";
const Square = (props) => {
  return <div className={props.size}></div>;
};
export default Square;
