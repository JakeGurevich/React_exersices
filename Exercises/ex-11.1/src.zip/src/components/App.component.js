import React from "react";
import Square from "./Square.component";
import Spiner from "./Spiner.componnet";
import Button from "./Button";
class App extends React.Component {
  state = { curColor: "" };
  handleClick = (color) => {
    console.log(color);
    this.setState({ curColor: color });
  };
  componentDidMount() {}
  componentDidUpdate() {}
  render() {
    return (
      <div>
        <Button onClick={this.handleClick} />
        {this.state.curColor}
      </div>
    );
  }
}

export default App;
