import React, { useState } from "react";
import axios from "axios";
import Button from "./Button";
import Joke from "./Joke";
import "./app.css";

const App = () => {
  const [joke, setJoke] = useState("");
  const [category, setCategory] = useState([]);
  const [specJoke, setspecJoke] = useState("");

  const fetchJoke = async () => {
    const res = await axios.get("https://api.chucknorris.io/jokes/random");
    console.log(res.data.value);
    setJoke(res.data.value);
  };
  const displayCategories = async () => {
    const res = await axios.get("https://api.chucknorris.io/jokes/categories");
    console.log(res.data);
    setCategory(res.data);
  };
  const fetchSpecJoke = async (c) => {
    const res = await axios.get(
      `https://api.chucknorris.io/jokes/random?category=${c}`
    );
    console.log(res.data.value);

    setspecJoke(res.data.value);
  };

  return (
    <div>
      <Button name="Get Joke" onClick={fetchJoke} />
      <Button name="Get Categories" onClick={displayCategories} />
      <Joke joke={joke} />
      <div className="category">
        {category.map((c, i) => {
          return <Button name={c} key={i} onClick={() => fetchSpecJoke(c)} />;
        })}
      </div>
      <Joke joke={specJoke} />
    </div>
  );
};

export default App;
