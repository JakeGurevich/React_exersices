import "./App.css";
import Button from "./Button.component";

const App = () => {
  return (
    <div>
      <Button text="importent" class="bold" />
      <Button text="not importent" />
    </div>
  );
};
export default App;
