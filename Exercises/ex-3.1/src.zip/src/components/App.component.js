import "./App.css";

const App = () => {
  return (
    <div className="green">
      <div className="blue">
        <div className="pink">
          <div className="purple"></div>
          <div className="purple"></div>
        </div>
      </div>
    </div>
  );
};
export default App;
