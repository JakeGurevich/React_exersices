const Display = (props) => {
  return;
};
export default Display;
