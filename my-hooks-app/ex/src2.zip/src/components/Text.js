import React, { useState } from "react";

const Text = (props) => {
  const [sec, setSec] = useState();
  const [min, setMin] = useState();
  const [hour, setHour] = useState();
  const inputHandler = (e) => {
    console.log(e.target.value);
  };

  return (
    <React.Fragment>
      <label for="sec">Seconds : </label>
      <input
        type="text"
        value={sec}
        id="sec"
        onChange={(e) => {
          inputHandler(e);
        }}
      ></input>
      <label for="min">Minuts : </label>
      <input type="text" id="min" value={min}></input>
      <label for="hour">Hours : </label>
      <input type="text" id="hour" value={hour}></input>
    </React.Fragment>
  );
};
export default Text;
